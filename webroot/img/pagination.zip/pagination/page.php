 <?php
include 'conn.php';
$result1=$conn->query("select user_id,first_name,last_name,email,phone_number,gender from users limit 0,5");
?> 

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    

    <style>
      .pagination {
  display: inline-block;
}

.pagination a {
  color: black;
  float: left;
  padding: 8px 16px;
  text-decoration: none;
}
    </style>
</head>
<body>
<form>
<table id="dtBasicExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
  <thead>
    <tr>
      <th class="th-sm">ID

      </th>
      <th class="th-sm">First name

      </th>
      <th class="th-sm">Last Name

      </th>
      <th class="th-sm">Email

      </th>
      <th class="th-sm">Phone

      </th>
      <th class="th-sm">Gender

      </th>
    </tr>
  </thead>
  <tbody>
  <?php while($show=$result1->fetch_assoc()){ ?>
						<tr>
                            <?php foreach($show as $x=>$y){ ?>
                                <td><?php echo $y ?></td>
                           <?php } ?>
                            
							
						</tr>
                        <?php } ?>

                            </tbody>
  
</table>
<div class="pagination">
  <a href="">&laquo;</a>
  <a href="">2</a>
  <a href="">3</a>
  <a href="">4</a>
  
  <a href="2">&raquo;</a>
</div>
 </form>

<script>

$(document).ready(function () {
            $('a').click(function (event) {
                event.preventDefault();
                $.ajax({
                    url: 'data.php',
                    type: 'post',
                    data:  {page : $(this).text()},
                    success: function(response) {
                        $("tbody").html(response);
                    }
        });
    });
});

</script>
</body>
</html>