<?php
include 'conn.php';

$y=5;

if(!isset($_POST['page']))
    {
        $id = 1;

    }
    else{
        $id= $_POST['page'];
    }


$x=$id*5;


echo $x;
echo $y;

$result1=$conn->query("select user_id,first_name,last_name,email,phone_number,gender from users limit $x,$y");

while($show=$result1->fetch_assoc()){
   echo "<tr>";
        foreach($show as $x=>$y){ 
            echo "<td>".$y."</td>";
       } 
        
        
       echo "</tr>";
    } 

?>