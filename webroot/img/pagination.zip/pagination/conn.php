<?php
ini_set("display_error",0);
$conn= new mysqli('localhost','root','password','assignment3');
if(!$conn)
{
    die("connection failed: " . mysqli_connect_error());
}

?>